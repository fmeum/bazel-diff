package cli.src.test.resources.integration.src.main.java.com.integration;

public class StringGenerator {
    public String createString() {
        return "AString";
    }
}
